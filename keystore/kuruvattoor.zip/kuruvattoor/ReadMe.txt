
1. Password

mocte$8316Zuma

2. Alias Name 

Kuruvattoor Bank

3. Alias password

mocte$8317Zuma 

4 Validity of this application (how many year this app should be valid default 25)

25 Yrs 

For certificate 

1. First name and last name

   General Manager

2. Organisation unit

  Head Office 

3. Organization

  Kuruvattoor Bank

4. City

Calicut 

5.State

Kerala 

6. country 

India